import React from 'react'

export default function page() {
  return (
    <h1>Protected</h1>
  )
}
